These icons are from Icojam (http://www.icojam.com)
(you can buy vector and hi-res version)

Cosmo mini free [bitmap]

Ammount of icons:
1566

Icon Sizes:
40x40

File Types:
.png: 
40x40(32bit)
